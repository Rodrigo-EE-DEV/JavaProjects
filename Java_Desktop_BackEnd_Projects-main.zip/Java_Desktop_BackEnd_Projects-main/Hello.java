//package not_a_project;

import java.util.*;

public class Hello{
    public static void main(String[] args){
        System.out.println(hello());
    }
    public static Integer hello(){
        System.out.println("hello world".toUpperCase());
        
        return 19;
    }
}


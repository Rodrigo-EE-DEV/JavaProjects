# Java_Desktop_BackEnd_Projects
Repository for my Java based projects that are not for android
